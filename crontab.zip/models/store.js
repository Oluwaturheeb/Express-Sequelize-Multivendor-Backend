import DataTypes from 'sequelize';

const store = {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
    //defaultValue: DataTypes.UUIDV4
  },
  userId: DataTypes.INTEGER,
  name: {
    type: DataTypes.STRING,
    unique: true,
  },
  email: DataTypes.STRING,
  avatar: DataTypes.TEXT,
  phone: DataTypes.BIGINT,
  long: DataTypes.FLOAT,
  lat: DataTypes.FLOAT,
  nationality: DataTypes.STRING,
  verifyPhone: {
    type: DataTypes.ENUM('0', '1'),
    defaultValue: '0',
  },
  verifyEmail: {
    type: DataTypes.ENUM('0', '1'),
    defaultValue: '0',
  },
};

export default store;