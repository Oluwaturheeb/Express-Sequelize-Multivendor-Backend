import DataTypes from 'sequelize';

const address = {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
    //defaultValue: DataTypes.UUIDV4
  },
  address: DataTypes.TEXT,
  lga: DataTypes.STRING,
  city: DataTypes.STRING,
  state: DataTypes.STRING,
  country: DataTypes.STRING,
};

export default address;