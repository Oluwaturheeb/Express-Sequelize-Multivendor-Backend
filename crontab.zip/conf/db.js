import {Sequelize, DataTypes} from 'Sequelize';
import users from '../models/users.js';
import orders from '../models/orders.js';
import items from '../models/items.js';
import store from '../models/store.js';
import address from '../models/address.js';

const seq = new Sequelize('multi', 'root', '', {
  dialect: 'postgres',
  url: process.env.DATABASE_URL,
  host: 'localhost'
});

export const Users = seq.define('users', users);
export const Orders = seq.define('orders', orders);
export const Items = seq.define('items', items(Users));
export const Store = seq.define('store', store);
export const Address = seq.define('address', address);

//relationship
// for sellers
Users.hasOne(Store);
Store.belongsTo(Users);
// get items for stores
Store.hasMany(Items);
Items.belongsTo(Store);

// get orders for sellers
Items.hasMany(Orders);
Orders.belongsTo(Items);

// Items.belongsTo(Users);

//get orders
Users.hasMany(Orders);
Users.hasMany(Address);

// orders and addresses inverse
Orders.belongsTo(Users);
Address.belongsTo(Users);

// seq.sync({force: true});
export default seq;